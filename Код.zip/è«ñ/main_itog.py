from machine import TouchPad, Pin, PWM, I2C, Timer
from MX1508 import *
from time import sleep, sleep_ms
from neopixel import NeoPixel
from bleuart import *
from micropython import const
import uasyncio as asio
from tcs import *
from servo import *

led2 = Pin(2, Pin.OUT)                 #Define PIN for Blue led on ESP Board
motor = [MX1508(4, 16), MX1508(18, 19), MX1508(25, 26), MX1508(32, 33)] #Define PIN for motors
s180 =  Servo(Pin(14))     #Define PIN for Servo
s360 = PWM(Pin(15, Pin.OUT))
s360.freq(50)
sp = 1023
comand = ''
an = 60
on = 40
an1=0
on1=0

# Define ISR for an UART input on BLE connection
def on_rx():
    global comand, on
    on = 1
    comand = uart.read().decode().strip()
    comand = comand[2:]

# Create BLE object
ble = bluetooth.BLE()

# Open UART session for BLE
uart = BLEUART(ble, "Morkovka")

# Map ISR to UART read interrupt
uart.irq(handler=on_rx)

def map(angle):
   min_duty = 26
   max_duty = 128
   duty = min_duty + (angle / 180.0) * (max_duty - min_duty)
   return int(duty)
s360.duty(map(90))
def servo(pin, angle):
   pin.duty(map(angle))
  
async def do_it(int_ms):
    global an, on, an1, on1
    while 1:
        await asio.sleep_ms(int_ms)
        print(comand)                  # Print code button on console
        if on:
            on
        if comand == '813':            # klick button "UP"
            for i in range(4):
                motor[i].forward(sp)   # All motors is on, move straight ahead
                led2.on()              # Blue led is ON
                time.sleep(0.2)        # Pause 100 ms
                led2.off()             # Blue led is OFF
        elif comand == '714':          # klick button "DOWN"
            for i in range(4):
                motor[i].reverse(sp)   # All motors is revers. Move DOWN
                led2.on()              # Blue led is ON
                time.sleep(0.2)        # Pause 100 ms
                led2.off()             # Blue led is OFF
        elif comand == '615':          # klick button "LEFT"
            motor[0].forward(sp)       # Front right motors is on
            motor[1].forward(sp)       # Back right motors is on 
            motor[2].reverse(sp)       # Front left motors is reverse
            motor[3].reverse(sp)       # Back left motors is reverse. Move LEFT
            led2.on()                  # Blue led is ON
            time.sleep(0.2)            # Pause 100 ms
            led2.off()                 # Blue led is OFF
        elif comand == '516':          # klick button "RIGHT"
            motor[2].forward(sp)       # Front left motors is on
            motor[3].forward(sp)       # Back left motors is on
            motor[0].reverse(sp)       # Front right motors is reverse
            motor[1].reverse(sp)       # Back right motors is reverse. Move RIGHT
            led2.on()                  # Blue led is ON
            time.sleep(0.2)            # Pause 100 ms
            led2.off()                 # Blue led is OFF
        elif comand in ['507', '606', '705', '804']: # No KLICK button. Move STOP
            for i in range(4):
                motor[i].stop()
        elif comand == '11:':          # klick  "1"
            s180.move(27)
            led2.on()                  # Blue led is ON
            time.sleep(0.2)            # Pause 100 ms
            led2.off()                 # Blue led is OFF
        elif comand == '219':          # klick  "2"
            s180.move(0)
            led2.on()                  # Blue led is ON
            time.sleep(0.2)            # Pause 100 ms
            led2.off()            # Blue led is OFF
        elif comand == '318':
            servo(s360, 180)
            sleep(0.125)
            servo(s360, 90)
            led2.on()
            time.sleep(0.5)
            led2.off()
        elif comand == '417':
            servo(s360, 0)
            sleep(0.125)
            servo(s360, 90)
            led2.on()
            time.sleep(0.2)
            led2.off()
        
        rgb = tcs.read(1)
        r, g, b = rgb[0], rgb[1], rgb[2]
        h, s, v = rgb_to_hsv(r, g, b)
        
        if v < 99:
            print('Black')
            np[0]=(0,0,0)
            np.write()
            col_id=4
        elif 100<v<999:
            if 0<h<40:
                print('Red')
                np[0]=(Lt,0,0)
                np.write()
                col_id=0
            elif 41<h<120:
                print('Yellow')
                np[0]=(Lt,Lt,0)
                np.write()
                col_id=1
            elif 121<h<160:
                print('Green')
                np[0]=(0,Lt,0)
                np.write()
                col_id=3
            elif 160<h<210:
                print('Cyan')
                np[0]=(0,Lt,Lt)
                np.write()
                col_id=5
            elif 211<h<240:
                print('Blue')
                np[0]=(0,0,Lt)

                np.write()
                col_id=6
            elif 241<h<300:
                print('Magenta')
                np[0]=(Lt,0,Lt)
                np.write()
                col_id=7
        elif v>1000:
            print('White')
            np[0]=(Lt,Lt,Lt)
            np.write()
            col_id=2

i2c_bus1 = I2C(0, sda=Pin(21), scl=Pin(22))
tcs = TCS34725(i2c_bus1)
tcs.gain(4)
tcs.integration_time(80)

NUM_OF_LED = 3
np = NeoPixel(Pin(23), NUM_OF_LED)
np[0]=(0,0,0)
Lt=40
col_id=0
int_ms=1
debug = 0

loop = asio.get_event_loop()
loop.create_task(do_it(5))
loop.run_forever()

